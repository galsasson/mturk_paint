<?php
 
define('DB_HOST', 'localhost');  // Database host
define('DB_NAME', 'mturk'); // Database being used
define('DB_USER', 'user');  // Database user
define('DB_PASS', '123456'); // Database user's password

?>

 
